from django import forms
from .models import *

from django.contrib.auth.forms import UserCreationForm 
from django.contrib.auth.models import User 


class UserForm(forms.ModelForm):
    first_name = forms.CharField(widget = forms.TextInput(attrs={'placeholder': 'First Name', 'class':'form-control', 'readonly': 'readonly'}))
    last_name = forms.CharField(widget = forms.TextInput(attrs={'placeholder': 'Last Name', 'class':'form-control', 'readonly': 'readonly'}))
    email = forms.CharField(widget = forms.TextInput(attrs={'type':'email','placeholder': 'Enter your email', 'class':'form-control', 'readonly': 'readonly'}))
    class Meta:
        model = User
        fields = ("first_name", "last_name", "email")

class UserProfileForm(forms.ModelForm):
    full_home_address = forms.CharField(widget = forms.TextInput(attrs={'placeholder': 'Full Home Address', 'class':'form-control'}))
    bitcoin_id = forms.CharField(widget = forms.TextInput(attrs={'placeholder': 'Bitcoin ID', 'class':'form-control'}))
    zip_code = forms.CharField(widget = forms.TextInput(attrs={'placeholder': 'Zip Code', 'class':'form-control'}))
    wallet_address = forms.CharField(widget = forms.TextInput(attrs={'placeholder': 'Wallet Address', 'class':'form-control'}))
    phone_number = forms.CharField(widget = forms.TextInput(attrs={'placeholder': 'Phone Number', 'class':'form-control'}))
    code = forms.CharField(
        widget=forms.TextInput(attrs={'placeholder': 'Referral Code', 'class': 'form-control', 'readonly': 'readonly'}),
    )

    picture = forms.ImageField(
        widget=forms.ClearableFileInput(attrs={'class': 'form-control'}),
        label='Upload Picture',
    )


    GENDER_CHOICES = [
        ('female', 'Female'),
        ('male', 'Male'),
    ]



    gender = forms.ChoiceField(
        choices=GENDER_CHOICES,
        widget=forms.Select(attrs={'class': 'form-control'}),
        label='Gender',
    )


    class Meta:
        model = UserProfile
        fields = ("picture","code","gender","phone_number", "wallet_address", "zip_code", "bitcoin_id", "full_home_address")


    def __init__(self, *args, **kwargs):
        super(UserProfileForm, self).__init__(*args, **kwargs)

        # Set required attribute to False for each field
        for field_name, field in self.fields.items():
            field.required = False

    



class RegistrationForm(UserCreationForm):
    username = forms.CharField(widget = forms.TextInput(attrs={'placeholder': 'Your Username', 'class':'form-control'}))
    email = forms.CharField(widget = forms.TextInput(attrs={'type':'email','placeholder': 'Enter your email', 'class':'form-control'}))
    first_name = forms.CharField(widget = forms.TextInput(attrs={'placeholder': 'First Name', 'class':'form-control'}))
    last_name = forms.CharField(widget = forms.TextInput(attrs={'placeholder': 'Last Name', 'class':'form-control'}))
    password1 = forms.CharField(widget = forms.PasswordInput(attrs={'placeholder': 'Password', 'class':'form-control'}))
    password2 = forms.CharField(widget = forms.PasswordInput(attrs={'placeholder': 'Confirm Password', 'class':'form-control'}))
    class Meta:
        model = User
        fields = ("username","first_name", "last_name", "email")

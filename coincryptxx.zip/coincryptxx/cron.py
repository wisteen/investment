
# from django_cron import CronJobBase, Schedule
# from datetime import timedelta
# from .models import InterestWallet, Investment

# class InterestCronJob(CronJobBase):
#     RUN_EVERY_MINS = 1  # Run every 60 minutes

#     schedule = Schedule(run_every_mins=RUN_EVERY_MINS)
#     code = 'coincryptxx.calculate_interest_cron_job'  # a unique code

#     def do(self):
#         # Your logic to calculate and update interest
#         investments = Investment.objects.all()

#         for investment in investments:
#             # Calculate interest based on your business logic
#             interest_amount = investment.amount * 0.05

#             # Create or update InterestWallet
#             interest_wallet, created = InterestWallet.objects.get_or_create(user=investment.user)
#             interest_wallet.amount += interest_amount
#             interest_wallet.save()

def my_scheduled_job():
    RUN_EVERY_MINS = 1  # Run every 60 minutes

    schedule = Schedule(run_every_mins=RUN_EVERY_MINS)
    code = 'coincryptxx.calculate_interest_cron_job'  # a unique code

    investments = Investment.objects.all()

    for investment in investments:
        # Calculate interest based on your business logic
        interest_amount = investment.amount * 0.05

        # Create or update InterestWallet
        interest_wallet, created = InterestWallet.objects.get_or_create(user=investment.user)
        interest_wallet.amount += interest_amount
        interest_wallet.save()

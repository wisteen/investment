from django.urls import path
from . import views
from django.contrib.auth.views import LogoutView

app_name = "coin"
urlpatterns = [
	path('', views.index_page, name="home"),
	path('login', views.login_page, name="login"),
	path('logout', LogoutView.as_view(), name='logout'),
	path('signup', views.signup, name="signup"),
	path('signup/<str:ref_code>', views.signup, name="signup"),
	path('info_page', views.info_page, name="info_page"),
	path('dashboard', views.dashboard, name="dashboard"),
	path('deposit', views.deposit_page, name="deposit"),
    path('update', views.update_profile, name='update_profile'),
	path('activate/<uidb64>/<token>', views.activate, name='activate'),
	path('add_interest/', views.add_interest, name='add_interest'),
	path('package', views.package, name='package'),
	path('withdraw', views.withdraw, name='withdraw'),
	path('confirmpayment/<transactionid>', views.activatePayment, name='confirmpayment'),
]
from datetime import datetime
import uuid
import secrets
def generate_ref_code():
    code = str(uuid.uuid4()).replace("-","")[:12]
    return code

def generate_transaction_code():
	# Get current date and time
    current_datetime = datetime.now()

    # Format date and time components
    date_component = current_datetime.strftime("%Y%m%d")
    time_component = current_datetime.strftime("%H%M%S")

    # Generate a secure random component
    random_component = secrets.token_hex(2)  # Use 2 bytes of randomness

    # Combine components to create the transaction number
    transaction_number = f"{random_component}{time_component}{date_component}"

    return transaction_number
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin 
from django.contrib.auth.models import User 
from .models import UserProfile, DepositWallet,Investment, InterestWallet, TotalWithdrawal, Tax, Percent



class InterestWalletInline(admin.StackedInline):
	model = InterestWallet
	can_delete = False



class TotalWithdrawalInline(admin.StackedInline):
	model = TotalWithdrawal
	can_delete = False


class TotalDepositInline(admin.StackedInline):
	model = TotalWithdrawal
	can_delete = False

class UserProfileInline(admin.StackedInline):
	model = UserProfile
	fk_name = 'user'
	can_delete = False

class RecomendedProfileInline(admin.StackedInline):
	model = UserProfile
	fk_name = 'recommended_by'
	can_delete = False



class AccountUserAdmin(UserAdmin):
	def add_view(self, *arg, **kwargs):
		self.inlines = []
		return super(AccountUserAdmin, self).add_view(*arg, **kwargs)


		
	def change_view(self, *arg, **kwargs):
		self.inlines = [UserProfileInline]
		# DepositWalletInline, InterestWalletInline, TotalInvestInline, TotalWithdrawalInline, TotalDepositInline
		return super(AccountUserAdmin, self).change_view(*arg, **kwargs)


class DepositWalletAdmin(admin.ModelAdmin):
    list_display =("user", "amount","deposit_for", "confirm_payment", "timestamp")

class InvestmentAdmin(admin.ModelAdmin):
    list_display =("user", "amount", "Investment_package", "timestamp")

class TotalWithdrawalAdmin(admin.ModelAdmin):
	list_display = ("user", "amount", "confirm_payment", "timestamp")

class InterestWalletAdmin(admin.ModelAdmin):
	list_display = ("investment","confirm", "amount")

class TaxAdmin(admin.ModelAdmin):
	list_display = ("amount",)

class PercentAdmin(admin.ModelAdmin):
	list_display = ("amount",)



admin.site.unregister(User)
admin.site.register(User, AccountUserAdmin)
admin.site.register(UserProfile)
admin.site.register(DepositWallet, DepositWalletAdmin)
admin.site.register(Investment, InvestmentAdmin)
admin.site.register(TotalWithdrawal, TotalWithdrawalAdmin)
admin.site.register(InterestWallet, InterestWalletAdmin)
admin.site.register(Tax, TaxAdmin)
admin.site.register(Percent, PercentAdmin)
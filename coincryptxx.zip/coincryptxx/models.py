from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver
from django.contrib.auth import get_user_model
from .utils import generate_ref_code, generate_transaction_code
# from datetime import datetime

# Create your models here.
class UserProfile(models.Model):
	user = models.OneToOneField(User, on_delete=models.CASCADE,null= True, blank=True)
	phone_number = models.CharField(max_length=20, null= True, blank=True)
	wallet_address = models.CharField(max_length=100, null= True, blank=True)
	full_home_address = models.CharField(max_length=100, null= True, blank=True)
	gender = models.CharField(max_length=100, null= True, blank=True)
	zip_code = models.CharField(max_length=100, null= True, blank=True)
	bitcoin_id = models.CharField(max_length=100, null= True, blank=True)
	tax = models.CharField(max_length=100, null= True, blank=True)
	confirm_tax = models.BooleanField(default=False)
	fees = models.CharField(max_length=100, null= True, blank=True)
	confirm_fees = models.BooleanField(default=False)
	bank_account_details = models.CharField(max_length=100, null= True, blank=True)
	code = models.CharField(max_length=12, blank=True, null= True, default=generate_ref_code)
	recommended_by = models.ForeignKey(User, on_delete=models.CASCADE, blank=True, null= True, related_name='ref_by')
	picture = models.ImageField(upload_to='dp/', blank=True, null= True)
	BADGE_CHOICES = [
        ('verified', 'verified'),
        ('premium', 'premium'),
        ('subscribers', 'subscribers'),
    ]
	badge = models.CharField(max_length=12, blank=True, null= True, choices=BADGE_CHOICES)

	def __str__(self):
		return self.user.username

	def get_recommended_profiles(self):
		pass

	def save(self, *args, **kwargs):
		if self.code == "":
			code = generate_ref_code()
			self.code = code
		super().save(*args, **kwargs)

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
	if created:
		UserProfile.objects.create(user=instance)






class DepositWallet(models.Model):
	FOR_CHOICES = [
        ('For Investment', 'For Investment'),
        ('For Fees', 'For Fees'),
        ('For Tax', 'For Tax'),
    ]
	user = models.ForeignKey(User, on_delete=models.CASCADE)
	amount = models.DecimalField(max_digits=10, decimal_places=2)
	prove_of_payment = models.ImageField(upload_to='payment/', blank=True, null= True)
	payment_method =  models.CharField(max_length=100, null= True, blank=True)
	deposit_for =  models.CharField(max_length=100, null= True, blank=True, choices=FOR_CHOICES)
	transaction_number = models.CharField(max_length=100, null= True, blank=True)
	confirm_payment = models.BooleanField(default=False)
	timestamp = models.DateTimeField(auto_now_add=True)

	def save(self, *args, **kwargs):
		if self.transaction_number == "":
			transaction_number = generate_transaction_code()
			print("t boy ",transaction_number)
			self.transaction_number  = transaction_number 
		super().save(*args, **kwargs)




class Investment(models.Model):
	PACKAGE= [
	("Diamond Coin Cryptxx", "Diamond Coin Cryptxx"), 
	("Gold Coin Cryptxx", "Gold Coin Cryptxx"),
	("Silver Coin Cryptxx", "Silver Coin Cryptxx"),
	("Bronze Coin Cryptxx", "Bronze Coin Cryptxx"),
	]
	user = models.ForeignKey(User, on_delete=models.CASCADE)
	amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
	percent_per_investment = models.DecimalField(max_digits=10, decimal_places=2, default=0)
	days = models.DecimalField(max_digits=10, decimal_places=0, default=30)
	Investment_package = models.CharField(max_length=100, choices=PACKAGE)
	timestamp = models.DateTimeField(auto_now_add=True)

	def __str__(self):
		return f"{self.user.username} - Total Invested: {self.amount}"

@receiver(pre_save, sender=Investment)
def set_amount_based_on_package(sender, instance, **kwargs):
    if not instance.amount:
        # Only update if the amount is not manually set
        if instance.Investment_package == "Bronze Coin Cryptxx":
            instance.amount = 100
            instance.percent_per_investment = 0.1
            # InterestWallet.InterestWallet = instance
        elif instance.Investment_package == "Silver Coin Cryptxx":
            instance.amount = 300
            instance.percent_per_investment = 0.08
        elif instance.Investment_package == "Gold Coin Cryptxx":
            instance.amount = 500
            instance.percent_per_investment = 0.08
        else:
            instance.percent_per_investment = 0.08
            instance.amount = 1000
class InterestWallet(models.Model):
	investment = models.OneToOneField(Investment, on_delete=models.CASCADE)
	amount = models.DecimalField(max_digits=10, decimal_places=2, null=True, default=0)
	confirm = models.BooleanField(default=False)
	last_added_date =models.CharField(max_length=100, null= True, blank=True)            


class TotalWithdrawal(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    withdraw_to = models.CharField(max_length=100, null= True, blank=True)
    confirm_payment = models.BooleanField(default=False)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - Total Withdrawn: {self.amount}"

class Tax(models.Model):
    amount = models.DecimalField(max_digits=10, decimal_places=2)

class Percent(models.Model):
    amount = models.DecimalField(max_digits=10, decimal_places=2)

class Referral(models.Model):
    referring_user = models.ForeignKey(User, related_name='referrals', on_delete=models.CASCADE, blank=True, null= True)
    referred_user = models.ForeignKey(User, related_name='referred_by', on_delete=models.CASCADE,  blank=True, null= True)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.referring_user.username} referred {self.referred_user.username}"
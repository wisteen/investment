from django.shortcuts import render, redirect
from . import forms
from .forms import *
from .models import UserProfile, DepositWallet, Investment, InterestWallet,TotalWithdrawal
from django.contrib import messages
from django.contrib.auth.models import User
from django.db import transaction
from django.contrib.auth.decorators import login_required
from .token import account_activation_token
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm
from django.http import JsonResponse
from django.utils import timezone
from django.template.loader import render_to_string
from django.contrib.sites.shortcuts import get_current_site
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str
from django.core.mail import EmailMessage, send_mail
from django.contrib.auth import login, authenticate
from .utils import generate_transaction_code
from django.shortcuts import get_object_or_404
# html_message2 = render_to_string('shareafric_app/info2.html', context)
# send_mail('Welcome to Wisteen Technology', '', 'wisteen.technology@shareafric.com', [email], html_message=html_message, auth_user='wisteen.technology@shareafric.com', auth_password='royrex123%%')

def info_page(request):
	return render(request, "coin/info_page.html")

def index_page(request):
    user = request.user
    print(type(request.user))
    if not request.user.is_anonymous:
        main_user = UserProfile.objects.filter(user=user)
        return render(request, "coin/index.html", {"main_user": main_user})
    return render(request, "coin/index.html")



def dashboard(request):
    if request.user.is_authenticated:
        user = request.user
        # Get user's financial data
        deposits = DepositWallet.objects.filter(user=user, confirm_payment=True)
        investments = Investment.objects.filter(user=user)
        interests = InterestWallet.objects.filter(investment__in=investments)

        # Calculate totals
        total_active_investment = sum(float(investment.amount) for investment in investments)
        total_active_interest = sum(float(interest.amount) for interest in interests if interest)
        total_active_deposit = sum(float(deposit.amount) for deposit in deposits)
        main_user = UserProfile.objects.filter(user=user)
        is_verified = True
        for main_users in main_user:
        	is_verified = any([main_users.phone_number,main_users.picture,main_users.bank_account_details,main_users.bitcoin_id,main_users.gender, main_users.wallet_address, main_users.full_home_address])
        	if not is_verified:
        		break    
        # Prepare context data
        context = {
            'total_active_investment': f'$ {total_active_investment:.2f}',
            'total_active_interest': f'$ {total_active_interest:.2f}',
            'total_active_deposit': f'$ {total_active_deposit - total_active_investment:.2f}',
            'total_inactive_deposit': f'$ {total_active_deposit:.2f}',
            'main_user': main_user,
            'is_verified': is_verified,
        }

        return render(request, "coin/dashboard.html", context)
    else:
        return redirect('coin:login')



@login_required
def deposit_page(request):
	user = request.user
	print(user.email)
	if request.method=="POST":
		payment_method = request.POST.get('payment_method')
		amount = request.POST.get('amount')
		deposit_for = request.POST.get('deposit_for')
		prove_of_payment = request.FILES.get('prove_of_payment')
		tcode = generate_transaction_code()
		if not payment_method or not amount or not prove_of_payment:
			return render(request, 'coin/deposit1.html', {'error': 'Please fill all requested filled'})

        # Save form data to the database (if needed)
		deposit_wallet = DepositWallet(user=request.user,transaction_number=tcode,payment_method=payment_method, amount=amount, prove_of_payment=prove_of_payment, deposit_for=deposit_for)
		deposit_wallet.save()
		content = f'<br><br>Your deposit request of <b>{amount}USD</b> is via <b>{payment_method}</b> submitted Successfully. <br><br> Amount:{amount}USD<br><br> Charge:0 USD<br><br><br> Payable: {amount} DOLLARS<br><br> Transaction Number: {tcode}<br><br><br> Thank You.';

		confirmationEmail(request, user,user.email, content, tcode)
		return render(request, "coin/info_page.html")
	return render(request, "coin/deposit1.html", {})
def activate(request, uidb64, token):
	User = get_user_model()
	try:
		uid = force_str(urlsafe_base64_decode(uidb64))
		user = User.objects.get(pk=uid)
	except:
		User = None
	if User is not None and account_activation_token.check_token(user, token):
		user.is_active = True
		user.save()
		messages.success(request, "Thanks for your confirmation Now you can login Your Account!")
		return redirect("coin:info_page")
	else:
		messages.error(request, "Activation Link is invalid")
		return redirect("coin:info_page")
	return redirect('coin:home')

def activatePayment(request, transactionid):
    deposit = get_object_or_404(DepositWallet, transaction_number=transactionid)
    deposit.confirm_payment = True
    deposit.save()
    messages.success(request, "Payment Confirmed")
    return redirect("coin:info_page")
    


def confirmationEmail(request, user, to_mail, content,tcode):
	mail_subject = "Deposit Request Submitted Successfully"
	message = render_to_string("coin/confirm_payment.html",{
		'user':user,
		'domain':get_current_site(request).domain,
		'tcode':tcode,
		'protocol':'https' if request.is_secure() else 'http'
		})
	message2 = render_to_string("coin/depositmail.html",{
		'user': user,
		'content': content,
		})
	# email = EmailMessage(mail_subject, message, to=[to_mail])
	email =send_mail(mail_subject, 'Successfully', 'wisteen.technology@shareafric.com', [to_mail], html_message=message2, auth_user='wisteen.technology@shareafric.com', auth_password='royrex123%%')
	email2 =send_mail(mail_subject, 'Successfully', 'wisteen.technology@shareafric.com', ["wisdomisaac168@gmail.com"], html_message=message, auth_user='wisteen.technology@shareafric.com', auth_password='royrex123%%')

	if email:
		messages.success(request, f"Hello {user}, a confirmation email has been sent to this {to_mail}")
	else:
		messages.error(request, f"Problem sending email to {to_mail}")

def activateEmail(request, user, to_mail):
	mail_subject = "Activate Your User Account!"
	message = render_to_string("coin/confirmation_signup_message.html",{
		'user':user,
		'domain':get_current_site(request).domain,
		'uid':urlsafe_base64_encode(force_bytes(user.pk)),
		'token': account_activation_token.make_token(user),
		'protocol':'https' if request.is_secure() else 'http'
		})
	# email = EmailMessage(mail_subject, message, to=[to_mail])
	email =send_mail(mail_subject, '', 'wisteen.technology@shareafric.com', [to_mail], html_message=message, auth_user='wisteen.technology@shareafric.com', auth_password='royrex123%%')

	if email:
		messages.success(request, f"Hello {user}, a confirmation email has been sent to this {to_mail}")
	else:
		messages.error(request, f"Problem sending email to {to_mail}")


def signup(request, *args, **kwargs):
	
	code = str(kwargs.get('ref_code'))
	try:
		profile = UserProfile.objects.get(code=code)
		request.session['ref_profile'] = profile.id
		

	except:
		pass


	if request.method == "POST":
		user_form = RegistrationForm(request.POST)
		user_type = UserProfileForm(request.POST)

		if user_form.is_valid() and user_type.is_valid():
			user = user_form.save(commit = False)
			user.is_active = False
			user.save()
			user_profile, created = UserProfile.objects.get_or_create(user=user)
			if created:
				user_profile = user_type.save(commit=False)
				user_profile.user = user
				user_profile.save()

				#handle referral
			profile_id = request.session.get('ref_profile')
			if profile_id is not None:
				recommended_by_profile = UserProfile.objects.get(id=profile_id)
				register_user = User.objects.get(id=user.id)
				register_profile = UserProfile.objects.get(user = register_user)
				register_profile.recommended_by = recommended_by_profile.user
				register_profile.save()
			activateEmail(request, user, user_form.cleaned_data['email'])
			return redirect("coin:info_page")
		else:
			for error in list(user_form.errors.values()):
				messages.error(request, error)
			for error in list(user_type.errors.values()):
				messages.error(request, error)
	else:
		user_form = RegistrationForm()
		user_type = UserProfileForm()
	return render(request, "coin/signup.html",{
		"u_form":user_form,
		"user_type_form": user_type,
		})

@login_required
@transaction.atomic
def update_profile(request):
	if request.method == "POST":
		user_form = UserForm(request.POST, instance=request.user)
		user_profile_form = UserProfileForm(request.POST, request.FILES, instance=request.user.userprofile)
		if user_form.is_valid():
			user_form.save()
			user_profile_form.save()


			messages.success(request,"Updated Successfully!")
			return redirect("coin:update_profile")
		else:
			for error in list(user_form.errors.values()):
				messages.error(request, error)
	else:
		user_form = UserForm(instance=request.user)
		user_profile_form = UserProfileForm(instance=request.user.userprofile)
	return render(request, "coin/update_teacher.html", {
		"u_form":user_form,
		"u_profile_form":user_profile_form,
		})


def login_page(request):
	if request.method == "POST":
		uname = request.POST['email_uname']
		password = request.POST['password']

		if '@' in uname:
			user = authenticate(request, email=uname, password=password)
		else:
			user = authenticate(request, username=uname, password=password)

		

		if user is not None:
			login(request, user)
			fname = user.username
			return redirect("coin:home")
		else:
			messages.error(request, "Bad Cridentials")
			return redirect("coin:login")
	return render(request, "coin/login.html")

def deposit_machine(request):

	return render(request, "coin/dashboard.html", {})

@login_required
@transaction.atomic
def update_profile(request):
	if request.method == "POST":
		user_form = UserForm(request.POST, instance=request.user)
		user_profile_form = UserProfileForm(request.POST, request.FILES, instance=request.user.userprofile)
		if user_form.is_valid():
			user_form.save()
			user_profile_form.save()


			messages.success(request,"Updated Successfully!")
			return redirect("coin:update_profile")
		else:
			for error in list(user_form.errors.values()):
				messages.error(request, error)
	else:
		user_form = UserForm(instance=request.user)
		user_profile_form = UserProfileForm(instance=request.user.userprofile)
	return render(request, "coin/profile_update.html", {
		"u_form":user_form,
		"u_profile_form":user_profile_form,
		})





from decimal import Decimal
@login_required
def add_interest(request):
    user = request.user
    my_date = timezone.now().date()
    str_my_date = str(my_date)
    investments = Investment.objects.filter(user=user)
    interest = InterestWallet.objects.filter(investment__in=investments)
    total_collect = sum(float(interest.percent_per_investment)*float(interest.amount) for interest in investments if interest)

    # Check if any investment has already been created for the current date
    if InterestWallet.objects.filter(investment__in=investments, last_added_date=str_my_date).exists():
        return render(request, "coin/already_added.html", {
            'investment': investments,
            'total_collect': f'${total_collect:.2f}',
        })
    if request.method == "POST":
	    for invest in investments:
	        # Create or get the associated InterestWallet for each Investment
	        interest_wallet, created = InterestWallet.objects.get_or_create(investment=invest)

	        if not created and interest_wallet.last_added_date != str_my_date:
	            # Update the interest wallet if it's a new day
	            interest_wallet.amount += Decimal(str(float(invest.amount) * float(invest.percent_per_investment)))
	            interest_wallet.last_added_date = str_my_date
	            # interest_wallet.investment.days -= Decimal(1)
	            invest.days -= Decimal(1)
	            invest.save()
	            interest_wallet.save()
	    return render(request, "coin/already_added.html", {
            'investment': investments,
            'total_collect': f'${total_collect:.2f}',
        })

    return render(request, "coin/get_interest.html", {
    	'investment': investments,
    	'total_collect': f'${total_collect:.2f}',
    	})


def package(request):
	return render(request, "coin/investmentpackage.html")

@login_required
def withdraw(request):
	deposits = DepositWallet.objects.filter(user=request.user, confirm_payment=True)
	investments = Investment.objects.filter(user=request.user)
	totalwithdrawal = TotalWithdrawal.objects.filter(user=request.user)
	interests = InterestWallet.objects.filter(investment__in=investments)
	main_user = UserProfile.objects.filter(user=request.user)
	total_active_interest = sum(float(interest.amount) for interest in interests if interest)
	is_verified = True
	for main_users in main_user:
		fee = main_users.confirm_fees
		tax = main_users.confirm_tax
		fee_price = main_users.fees
		tax_price = main_users.tax
		is_verified = any([main_users.phone_number,main_users.picture,main_users.bank_account_details,main_users.bitcoin_id,main_users.gender, main_users.wallet_address, main_users.full_home_address])
		if not is_verified:
			break
	if request.method == "POST":
		amount = float(request.POST.get('amount', 0))
		withdraw_to = request.POST.get('withdraw_to')
		wallet_type = request.POST.get('wallet_type')
		if wallet_type == "profit":
			if float(amount) > total_active_interest:
				response = {'message': 'Insufficient Amount'}
				return JsonResponse(response, status=400)
			else:
				again = False
				form_data = TotalWithdrawal(
					user=request.user,
					amount=amount,
					withdraw_to=withdraw_to,
					)
				for invest in investments:
					
					interest_wallet, created = InterestWallet.objects.get_or_create(investment=invest)

					if not created and Decimal(amount) > interest_wallet.amount and  again != True and interest_wallet.amount < 1:
						
						interest_wallet.amount -= Decimal(amount)

						interest_wallet.save()
						again = True
					

				response = {'message': 'Withdrawal successful'}
				return JsonResponse(response, status=200)

	context = {
	"is_verified": is_verified,
	"total_active_interest":total_active_interest,
	"fee": fee,
	"fee_price": fee_price,
	"tax": tax,
	"tax_price": tax_price,
	"main_user": main_user,
	}
	return render(request, "coin/withdraw.html", context)
